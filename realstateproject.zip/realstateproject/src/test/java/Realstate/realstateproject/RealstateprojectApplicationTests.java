package Realstate.realstateproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealstateprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
